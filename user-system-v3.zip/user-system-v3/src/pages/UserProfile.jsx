import { useParams } from "react-router-dom";
import { dataBase } from "../../usersData/data";
import ProfilePicture from "../components/profilePicture/ProfilePicture";
import UserInfo from "../components/userInfo/UserInfo";
import "./UserProfile.css"




export default () => {
    const {id} = useParams()
    const user = dataBase.users.find((user) => user.id=id)
    
    return(
        <div className="user-profile-container">
        <ProfilePicture/>
        <UserInfo user={user}/>
        </div>
    )
}