import { dataBase } from "../../usersData/data"
import UserCard from "../components/userCard/UserCard"
import "./Home.css"

export default () => {
    return (
        <>
        <div className="user-card-container">
            {dataBase.users.map((user, index) => (
                <UserCard key={index} imgUrl="user.png" userName={user.name} id={user.id}/>
            ))}
        </div>
            
        </>
    )
}
