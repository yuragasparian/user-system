import { useParams } from "react-router-dom";
import { dataBase } from './../../usersData/data';
import PostList from "../components/postList/PostList";
import "./Posts.css"

export default () => {
    const { id } = useParams()
    const posts = dataBase.posts.filter((post) => post.userId == id)

    return (
    <div className="posts-container">
        {posts.map((post) => (
                <PostList post={post} key={post.id} />
            )
            )}
    </div>    
    )
}
    
