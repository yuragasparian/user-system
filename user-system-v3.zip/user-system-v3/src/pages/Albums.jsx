import "./Albums.css"
import { useParams } from "react-router-dom";
import { dataBase } from './../../usersData/data';
import AlbumList from "../components/albumList/AlbumList";
import "./Albums.css"



export default () => {
    const { id } = useParams()
    const albums = dataBase.albums.filter((album) => album.userId == id)

    return (
        <div className="albums-container">
            {albums.map((album) => (
                <AlbumList album={album} key={album.id} />
            )
            )}
        </div>
    )
}