import { dataBase } from "../../usersData/data"
import { useParams } from 'react-router-dom';
import ImageList from "../components/imageList/ImageList";
import "./Images.css"

export default () => {
    const {albumId} = useParams()
    const images = dataBase.images.filter((image) => image.albumId==albumId)
    return(
      <div className="images-container">
        {images.map((image) => <ImageList images={image} key={image.id}/>)}
        
        </div>    
    )
}
    