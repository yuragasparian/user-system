import Home from './pages/Home';
import { BrowserRouter as Router,Routes, Route } from 'react-router-dom';
import UserProfile from './pages/UserProfile';
import Albums from './pages/Albums';
import Posts from './pages/Posts';
import Images from './pages/Images';


function App() {

  return (

    <Router>
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/users/:id" element={<UserProfile />} />
      <Route path="/users/:id/albums" element={<Albums />} />
      <Route path="/users/:id/posts" element={<Posts />} />
      <Route path="/albums/:albumId" element={<Images />} />
      </Routes>
    </Router>

  )
}

export default App
