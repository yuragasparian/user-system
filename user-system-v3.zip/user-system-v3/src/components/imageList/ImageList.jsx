import "./ImageList.css"
export default ({ images }) => (
    <div className="image-body">
        <img className="image" src={images.thumbnailUrl} alt="[image not found]" />
        <p className="image-title">{images.title}</p>
    </div>
)