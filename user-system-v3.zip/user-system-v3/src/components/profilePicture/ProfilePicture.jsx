import "./ProfilePicture.css"
import { Link } from 'react-router-dom';

export default () => (
    <div className="profile-picture-container">
        <img src="/user.png" alt="Profile Picture" className="profile-picture" />
        <div className="buttons">
            <Link to={`posts`}>
                <button type="button">Posts</button>
            </Link>
            <Link to={`albums`}>
                <button type="button">Albums</button>
            </Link>
        </div>
    </div>
)