import { Link } from "react-router-dom"
import "./UserCard.css"

export default ({ imgUrl, userName, id }) => (
        <Link to={`/users/${id}`} className="user-card-body">
            <img src={imgUrl} alt="image" className="user-card-img" />
            <h4 className="user-card-name">{userName}</h4>
        </Link>
    
)