import { Link } from "react-router-dom"
import "./PostList.css"

export default ({post}) => (
    <Link to={`/posts/${post.id}`} className="post-body">
        <h4 className="post-title">{post.title}</h4>
        <p className="post-text">{post.body}</p>
    </Link>
)