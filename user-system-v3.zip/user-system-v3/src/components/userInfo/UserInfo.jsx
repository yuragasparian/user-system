import "./UserInfo.css"

export default ({user}) => (
    <div className="user-info">
        <p>User ID: {user.id}</p>
        <p>Name: {user.name}</p>
        <p>Username: {user.username}</p>
        <p>Email: {user.email}</p>
        <hr style={{ border: "1px solid gray", margin: "5px 0" }} />

        <p>Address:</p>
        <ul>
          <li>Street: {user.address.street}</li>
          <li>Suite: {user.address.suite}</li>
          <li>City: {user.address.city}</li>
          <li>Zipcode: {user.address.zipcode}</li>
          <li>
            Geo:
            <ul>
              <li>Lat: {user.address.geo.lat}</li>
              <li>Lng: {user.address.geo.lng}</li>
            </ul>
          </li>
        </ul>
        <hr style={{ border: "1px solid gray", margin: "5px 0" }} />

        <p>Phone: {user.phone}</p>
        <p>Website: {user.website}</p>
        <p>Company name: {user.company.name}</p>
        <ul>
          <li>Catch Phrase: {user.company.catchPhrase}</li>
          <li>BS: {user.company.bs}</li>
        </ul>
    </div>
)