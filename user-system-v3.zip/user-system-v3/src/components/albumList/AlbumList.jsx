import { Link } from "react-router-dom"
import "./AlbumList.css"

export default ({album}) => (
    <Link to={`/albums/${album.id}`} className="album-body">
        <img className="album-image" src="/album-icon.png" alt="album"/>
        <p className="album-title">{album.title}</p>
    </Link>
)